{
   printf("\nTA2GammaDeuterium : Analysis of gd->pipip / gd->pi0pn \n\n");

}

